stb
-------------------
single-file public domain (or MIT licensed) libraries for C/C++
-------------------
https://github.com/nothings/stb
-------------------
stv_vorbis.c (renamed into h) version 1.22

decode ogg vorbis files from file/memory to float/16-bit signed output
